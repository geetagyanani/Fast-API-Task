from pydantic import BaseModel
from typing import List

class AddressCreate(BaseModel):
    longitude : str
    latitude : str


class Address(BaseModel):
    id: int
    longitude : str
    latitude : str

    class Config:
        orm_mode = True

