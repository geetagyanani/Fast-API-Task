from tokenize import Floatnumber
from sqlalchemy import Column, Integer, String
from database import Base


class Address(Base):
    __tablename__ = 'address'
    id = Column(Integer, primary_key=True)
    longitude = Column(String(400))
    latitude = Column(String(400))
    