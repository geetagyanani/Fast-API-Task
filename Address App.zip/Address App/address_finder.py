from geopy.geocoders import Nominatim
from geopy.distance import geodesic


def location_finder(address_list,distance,longitude,latitude):
    add=[]
    for i in address_list:
        left=float(i.longitude)
        right=float(i.latitude)
        dist=geodesic((left,right),(float(longitude),float(latitude))).km
        if dist < int(distance):
            geolocator = Nominatim(user_agent="app")
            location = geolocator.reverse((left,right))
            if location:
                add.append(location.address)
   
    return add



    

