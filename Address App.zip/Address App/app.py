from typing import List
from fastapi import FastAPI, status, HTTPException, Depends, Response
from database import Base, engine, SessionLocal
from sqlalchemy.orm import Session
from address_finder import location_finder
import models
import schemas


Base.metadata.create_all(engine)


app = FastAPI()


def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()



@app.post("/address", response_model=schemas.Address, status_code=status.HTTP_201_CREATED)
def create_address(address: schemas.AddressCreate, session: Session = Depends(get_session)):
    
    if (float(address.longitude)> (-90) and float(address.longitude)< (90) and float(address.latitude)>(-180) and float(address.latitude)< (180)):
        addressdb = models.Address(longitude = address.longitude,latitude=address.latitude)
        session.add(addressdb)
        session.commit()
        session.refresh(addressdb)
    else:
        addressdb=None
    if addressdb == None:
        raise HTTPException(status_code=404, detail=f"Invalid Longitude or Latitude")
    return addressdb

@app.get("/address/{distance}", response_model=List)
def read_address(distance: str, longitude:str, latitude:str, session: Session = Depends(get_session)):

    
    address_list = session.query(models.Address).all()
    addresses=location_finder(address_list,distance,longitude,latitude)

    
    if not addresses:
        raise HTTPException(status_code=404, detail=f"Address not found")
    return addresses

@app.put("/address/{id}", response_model=schemas.Address)
def update_address(id: int, longitude : str, latitude : str, session: Session = Depends(get_session)):

    
    address = session.query(models.Address).get(id)

    
    if address:
        address.longitude = longitude
        address.latitude = latitude
        session.commit()

    
    if not address:
        raise HTTPException(status_code=404, detail=f"address item with id {id} not found")

    return address

@app.delete("/address/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_address(id: int, session: Session = Depends(get_session)):

    
    address = session.query(models.Address).get(id)

    
    if address:
        session.delete(address)
        session.commit()
    else:
        raise HTTPException(status_code=404, detail=f"address item with id {id} not found")

    return None

@app.get("/address", response_model = List[schemas.Address])
def read_address_list(session: Session = Depends(get_session)):

    
    address_list = session.query(models.Address).all()

    return address_list